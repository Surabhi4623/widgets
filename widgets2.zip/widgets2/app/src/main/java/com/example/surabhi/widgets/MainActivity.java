package com.example.surabhi.widgets;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
   TextView textView2,textView3,textView4;
   CheckBox checkbox;
   RadioButton radioButton;
   RadioGroup rg;
   SeekBar sk;
   ImageView img;
   Switch switch1;
   ToggleButton toggleButton;
   RelativeLayout r1;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        r1=(RelativeLayout)findViewById(R.id.RelativeLayout1);
        textView2=(TextView)findViewById(R.id.textView2);
        textView3=(TextView)findViewById(R.id.textView3);
        textView4=(TextView)findViewById(R.id.textView4);
        switch1=(Switch)findViewById(R.id.switch1);
        toggleButton=(ToggleButton)findViewById(R.id.toggleButton);
        rg=(RadioGroup) findViewById(R.id.rg);
        img=(ImageView) findViewById(R.id.img);
        final SeekBar sk=(SeekBar)findViewById(R.id.sk);
        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                textView4.setTextSize(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(toggleButton.isChecked())
                {
                    r1.setBackgroundResource(R.drawable.img1);
                }
                else
                {
                    r1.setBackgroundResource(R.drawable.img2);
                }
            }
        });
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked)
                {

                    Animation startRotateAnimation= AnimationUtils.loadAnimation(getApplicationContext(),R.anim.android_rotate_animation);
                    img.startAnimation(startRotateAnimation);
                }

            }
        });

    }

    public void checked(View v)
    {
        if(((CheckBox) v ).isChecked())
        {
            textView2.setText("Checkbox is selected");
        }
        else
        {
            textView2.setText("CheckBox is not selected");
        }
    }
    public void gender(View v)
    {
        int radioid=rg.getCheckedRadioButtonId();
        radioButton=findViewById(radioid);
        textView3.setText(radioButton.getText());
    }



}
